public class Opskrifter {
    private String titel;
    private String ingredienser;
    private String fremgangsmåde;

    public Opskrifter(String titel, String ingredienser, String fremgangsmåde) {
        this.titel = titel;
        this.ingredienser = ingredienser;
        this.fremgangsmåde = fremgangsmåde;
    }

    public String toString() {
        return String.format("Titel: %s\n" +
                "Ingredienser: %s\n\n" +
                "Fremgangsmåde: %s", titel, ingredienser, fremgangsmåde);
    }
}
