import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Boolean running = true;

        Scanner scanner = new Scanner(System.in);

        while (running){

            System.out.println("1. Tilføj en opskrift\n");
            System.out.println("2. Søgning\n");

            int valg = scanner.nextInt();
            switch (valg){
                case 1:
                    opretOpskrit();
            }
            System.out.println("");



        }


        //Tests
        //Task 1:
        //testTask1();
    }

    public void opretOpskrit(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Titel:");
        //String title = scanner
        Opskrifter test = new Opskrifter("Pizza", "Ost, Skinke", "lav den");
        System.out.println(test);
    }

}
